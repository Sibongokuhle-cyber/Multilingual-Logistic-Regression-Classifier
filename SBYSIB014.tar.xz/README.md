# README

## Student Information
- **Name:** Sibongokuhle Sibiya  
- **Student Number:** SBYSIB014  
- **Course:** CSC2042S  
- **Assignment:** 3 – Logistic Regression for English and isiXhosa Text Classification  
- **Submission Date:** 05 October 2025  

---

## Overview
This submission contains a Jupyter notebook and a PDF report for **Assignment 3**, which implements a multinomial logistic regression model for text classification in English and isiXhosa datasets. The objectives were to preprocess the data, implement the model using PyTorch, perform hyperparameter tuning, evaluate performance, and analyze model weights.

---

## Contents
- `Assignment3.ipynb`  
  Jupyter notebook containing full implementation: data processing, model definition, training, hyperparameter tuning, evaluation, and weight analysis.

- `Assignment3_Report.pdf`  
  Short PDF report (maximum 5 pages) summarizing OOP design, hyperparameter tuning decisions, evaluation results, and key insights.

- `README.md`  
  This file, containing setup instructions and an overview of the submission.

---

## Setup Instructions
1. **Requirements**  
   Ensure the following Python packages are installed:  
   ```bash
   numpy
   pandas
   scikit-learn
   matplotlib
   torch

2. **Running the Notebook**
	Open Assignment3_LogisticRegression.ipynb in Jupyter Notebook or Jupyter Lab.
	Place the English and isiXhosa datasets in the same directory as the notebook.
	Run all cells sequentially. Metrics, plots, and results will be generated automatically.

3. **Reproducibility**
	A fixed random seed has been set in the notebook to ensure consistent results across runs.
	No additional configuration is needed.

Class Overview

	The notebook follows a modular object-oriented design with the following main classes:
	
	TextDataset: Handles tokenization, vectorization, and batching for training, validation, and testing.
	LogisticRegressionModel: Defines a linear layer with softmax output for classification.
	Trainer: Manages training loops, loss computation (cross-entropy), and early stopping.
	Evaluator: Computes accuracy, precision, recall, F1 score, and confusion matrices.
	
	This structure allows easy adaptation to different feature extraction methods, datasets, and      hyperparameter configurations.

Notes

	The datasets are not included in this submission. Use the course-provided English and isiXhosa datasets.
	The notebook is fully documented with comments and markdown explanations.
	Hyperparameter tuning, weight analysis, and class imbalance handling are fully implemented and explained in the notebook and report.

References

	Course Lecture Slides and Notes (2025). University of Cape Town, Department of Computer Science. Materials on supervised learning, logistic regression, feature extraction, and model evaluation.
	Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825–2830.
	YouTube (2025). Tutorials on logistic regression, hyperparameter tuning, and text classification in Python and PyTorch.
	ChatGPT (2025). Assisted with report structuring, explanation of logistic regression concepts, interpretation of weight analysis, and diagram illustrations.
